INSERT INTO codpostal_ext SELECT * FROM ext_codpostal;

drop table 	EXT_CODPOSTAL	cascade constraints;


