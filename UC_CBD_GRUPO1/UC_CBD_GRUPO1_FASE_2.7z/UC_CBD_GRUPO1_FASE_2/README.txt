Caso deseje criar um user para testes executar o ficheiro:
-create_project_user

Para testar o projeto inserir os seguintes comando no command line:
-mkdir brightbank
-cd brightbank
-mkdir externals

Em seguida inserir os txt da pasta com o nome (Data) dentro da pasta criada (externals);

Ordem de inserção de scripts:
1. tablespaces
2. external
3. sequencias
4. tabelas
5. funções
6. procedimentos
8. triggers
7. views
8. index
9. exemplos
