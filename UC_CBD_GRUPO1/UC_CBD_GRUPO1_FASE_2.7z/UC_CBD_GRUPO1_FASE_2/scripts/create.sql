-- opções para configuração dos outputs: não são comandos SQL
SET PAGESIZE 100
SET LINESIZE 200

-- execução dos scripts para criação do caso de estudo usado nas fichas relativas à matéria de SQL

@@ drop
@@ tablespaces
@@ external
@@ sequencias
@@ tabelas
@@ funções
@@ procedimentos
@@ views
@@ Exemplos