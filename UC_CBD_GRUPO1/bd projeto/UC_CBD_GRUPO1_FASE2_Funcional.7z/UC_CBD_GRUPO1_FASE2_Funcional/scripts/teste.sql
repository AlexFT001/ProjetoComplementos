CREATE OR REPLACE PROCEDURE SP_TRANSACAO_ALEATORIO
    (
    quantidade number
    )
AS
    randomNumber NUMBER(10);
    plataforma transacao.vc_plataforma%type;
    valor NUMBER(6,2);
    quantidadevalores1 number(4);
    quantidadevalores2 number(4);
    operacao transacao.nb_operacao%type;
    categoria transacao.nb_categoria%type;
    clienteTransacao transacao.nb_ncliente%type;
    contatransacao transacao.nb_iban%type;
    emailcliente varchar2(20);
    contarecetora number(16);
    operacaoNome varchar2(20);
    tipoconta varchar2(20);
    contaSaldo NUMBER(10,2);
    contaRecetoraSaldo NUMBER(10);
    cartao NUMBER(4);
    quantidadeCartoes NUMBER(10);
BEGIN
    FOR i in 1..quantidade
    LOOP
    randomNumber := numeroaleatorio(1,3);

    IF randomNumber = 1 THEN
		plataforma := 'WEB';
	ELSE
		plataforma := 'ATM';
	END IF;

    valor := numerodecimalaleatorio(10,999999);

    SELECT COUNT(nb_operacao)
    INTO quantidadevalores1
    FROM operacao;

    quantidadevalores1 := numeroaleatorio(1000, (quantidadevalores1+1000));

    SELECT nb_operacao, vc_nome_operacao
    INTO operacao, operacaonome
    FROM operacao
    WHERE nb_operacao = quantidadevalores1;

    SELECT COUNT(nb_categoria)
    INTO quantidadevalores2
    FROM categoria;

    quantidadevalores2 := numeroaleatorio(1000, (quantidadevalores2+1000));

    SELECT nb_categoria
    INTO categoria
    FROM categoria
    WHERE nb_categoria = quantidadevalores2;

    SELECT a.nb_ncliente, a.nb_iban, c.nb_numerocartao
    INTO clienteTransacao, contatransacao, cartao
    FROM (SELECT  nb_ncliente, nb_iban FROM titular
    ORDER BY dbms_random.value) a, cartao c
    WHERE rownum =1 and a.nb_ncliente = c.nb_ncliente and a.nb_iban = c.nb_iban;

IF plataforma = 'WEB'
    THEN
            SELECT nb_iban
            INTO contarecetora
            FROM
            (SELECT  nb_iban FROM conta
            ORDER BY dbms_random.value)
            WHERE rownum =1 AND nb_iban != contatransacao;

            SELECT nb_operacao, vc_nome_operacao
            INTO operacao, operacaonome
            FROM operacao
            WHERE vc_nome_operacao LIKE 'TRANSFERENCIA';
ELSE
    IF operacaonome = 'TRANSFERENCIA'
    THEN
            SELECT nb_iban
            INTO contarecetora
            FROM
            (SELECT  nb_iban FROM conta
            ORDER BY dbms_random.value)
            WHERE rownum =1 AND nb_iban != contatransacao;
    ELSE
        contarecetora := null;
    END IF;
END IF;

    SELECT vc_tipo, nb_saldo
    INTO tipoconta, contasaldo
    FROM conta
    WHERE nb_iban = contatransacao;

    IF contarecetora IS NOT NULL
    THEN
        SELECT nb_saldo
        INTO contarecetorasaldo
        FROM conta
        WHERE nb_iban = contarecetora;
    END IF;

IF emailcliente IS NOT NULL
   OR tipoconta LIKE 'ORDEM'
   OR valor <= contasaldo

THEN
    INSERT INTO TRANSACAO (VC_plataforma, nb_valor, dta_dtatransacao, nb_categoria, nb_operacao, nb_ncliente, nb_iban, nb_IBANRecetor, nb_Cartao)
    VALUES (plataforma, valor,TO_DATE(current_date,'dd/mm/yyyy'),categoria,operacao,clienteTransacao,contatransacao,contarecetora, cartao);

    IF contarecetora IS NULL
    THEN
        IF operacaonome LIKE 'LEVANTAMENTO'
        THEN
            update_specifc_register('CONTA', contatransacao,'nb_saldo' , (contasaldo-valor) );
        ELSE
            update_specifc_register('CONTA', contatransacao,'nb_saldo' , (contasaldo+valor) );
        END IF;
    ELSE
            update_specifc_register('CONTA', contarecetora,'nb_saldo' , (contarecetorasaldo+valor) );
    END IF;

END IF;
END LOOP;
END SP_TRANSACAO_ALEATORIO;
/