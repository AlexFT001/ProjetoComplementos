
CREATE OR REPLACE TRIGGER alteracoes
  AFTER
    INSERT OR
    UPDATE OR
    DELETE
  ON CLIENTE
FOR EACH ROW
DECLARE
  operation VARCHAR2(10);
  cliente_pk NUMBER;
BEGIN
    IF INSERTING THEN
      operation := 'INSERT';
      cliente_pk := :NEW.nb_ncliente;
    ELSIF  UPDATING THEN
      operation := 'UPDATE';
      cliente_pk := :NEW.nb_ncliente;
    ELSIF  DELETING THEN
      operation := 'DELETE';
      cliente_pk := :OLD.nb_ncliente;
  END IF;
  INSERT INTO AlteracoesCliente (operation, user_logged, dataAlteracao, clientealterado)
  VALUES (operation, USER, SYSDATE, cliente_pk);

END alteracoes;
/