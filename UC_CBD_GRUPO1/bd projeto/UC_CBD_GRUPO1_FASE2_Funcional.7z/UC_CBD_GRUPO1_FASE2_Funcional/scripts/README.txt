Caso necessário, utilize o CriarUser como documento base para proseguir com todas as seguintes criações de tabelas
-altereEsseNOmeTablespace: deverá ser o nome da tablespace para o projeto
-aletereEsseTBMUser:  deverá ser o nome do user para o projeto

Para testar o projeto inserir os seguintes comando no command line:
-mkdir brightbank
-cd brightbank
-mkdir externals

Em seguida inserir o codPostal.txt dentro da pasta criada (externals);

Ordem de inserção de scripts:
1. tablespaces
2. external
3. sequencias
4. tabelas
5. funções
6. procedimentos
7. inserts
